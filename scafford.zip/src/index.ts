#!/usr/bin/env node

/**
 * 前端脚手架MCP服务器入口文件
 */

import './server.js';